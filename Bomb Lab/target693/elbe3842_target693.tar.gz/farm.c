/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_148()
{
    return 3284634952U;
}

unsigned getval_219()
{
    return 2425379013U;
}

unsigned getval_484()
{
    return 2462550344U;
}

void setval_445(unsigned *p)
{
    *p = 3284633928U;
}

void setval_491(unsigned *p)
{
    *p = 2425378870U;
}

unsigned getval_315()
{
    return 3281032280U;
}

void setval_389(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_194(unsigned x)
{
    return x + 2417555054U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_252()
{
    return 3221803405U;
}

void setval_327(unsigned *p)
{
    *p = 2462222831U;
}

unsigned getval_357()
{
    return 3281047169U;
}

void setval_212(unsigned *p)
{
    *p = 3682910857U;
}

unsigned addval_406(unsigned x)
{
    return x + 3380920969U;
}

unsigned getval_382()
{
    return 3232023177U;
}

unsigned addval_350(unsigned x)
{
    return x + 3286272329U;
}

unsigned addval_446(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_203()
{
    return 2497743176U;
}

unsigned getval_207()
{
    return 3385115273U;
}

void setval_229(unsigned *p)
{
    *p = 3224948425U;
}

unsigned getval_439()
{
    return 3223372424U;
}

unsigned getval_201()
{
    return 3374370433U;
}

unsigned addval_431(unsigned x)
{
    return x + 2425409945U;
}

unsigned addval_447(unsigned x)
{
    return x + 3229929097U;
}

unsigned addval_140(unsigned x)
{
    return x + 2430642504U;
}

unsigned addval_295(unsigned x)
{
    return x + 3383021961U;
}

void setval_424(unsigned *p)
{
    *p = 3224949129U;
}

unsigned getval_240()
{
    return 3286272840U;
}

unsigned getval_316()
{
    return 3221802633U;
}

void setval_116(unsigned *p)
{
    *p = 3375944073U;
}

void setval_367(unsigned *p)
{
    *p = 2425537161U;
}

void setval_323(unsigned *p)
{
    *p = 3767101627U;
}

void setval_250(unsigned *p)
{
    *p = 3285288963U;
}

void setval_285(unsigned *p)
{
    *p = 3224424841U;
}

unsigned addval_132(unsigned x)
{
    return x + 2430634312U;
}

void setval_254(unsigned *p)
{
    *p = 3232023177U;
}

unsigned addval_297(unsigned x)
{
    return x + 3767093256U;
}

unsigned getval_325()
{
    return 3281047169U;
}

void setval_182(unsigned *p)
{
    *p = 3685011849U;
}

unsigned addval_339(unsigned x)
{
    return x + 3374370473U;
}

void setval_239(unsigned *p)
{
    *p = 3352201616U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
